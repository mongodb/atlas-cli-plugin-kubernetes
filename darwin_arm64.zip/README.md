# Atlas CLI Kubernetes Plugin

The Atlas CLI Kubernetes Plugin is a first class plugin, providing kubernetes commands for the MongoDB Atlas CLI.
